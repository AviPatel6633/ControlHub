import "bootstrap/dist/css/bootstrap.min.css";
import { Poppins } from "next/font/google";
import "./globals.css";
import Script from "next/script";
import Header from "@/component/header/page";
import Footer from "@/component/footer/page";
import { BlogReposContextProvider } from "@/context/BlogReposContext";
import { Suspense } from "react";
import Loading from "./loading";
import JsonLd from "@/component/jsonID";
// import { GoogleTagManager } from '@next/third-parties/google'

const poppins = Poppins({
  subsets: ["latin", "latin-ext"],
  display: "swap",
  variable: "--font-poppins",
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
});

export const metadata = {
  title: "Australia's Trusted Trucking & Transport Company | Alpha Trucking",
  other: {
    "google-site-verification": "xsdg0vqMeQsWNtuu1zMPs_ObbgiJqxd8SxYFPkXzszE",
    "p:domain_verify": "cbb61b1b4e48912ec9d50b1061a8e0af",
  },
};

export default function RootLayout({ children }) {
  return (
    <>
      <html lang="en" className={poppins.variable}>
        {/* Google Tag Manager */}
        {/* <GoogleTagManager gtmId="GTM-XYZ" /> */}
        <head>
          {/* Google Tag Manager */}
          <Script
            id="gtm-script"
            dangerouslySetInnerHTML={{
              __html: `
      (function (w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({ "gtm.start": new Date().getTime(), event: "gtm.js" });
        var f = d.getElementsByTagName(s)[0],
          j = d.createElement(s),
          dl = l != "dataLayer" ? "&l=" + l : "";
        j.async = true;
        j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
        f.parentNode.insertBefore(j, f);
      })(window, document, "script", "dataLayer", "GTM-NZJBVMWL");
    `,
            }}
            strategy="lazyOnload"
          />
          {/* End Google Tag Manager */}

          {/* Google tag (gtag.js)  */}
          <Script
            src="https://www.googletagmanager.com/gtag/js?id=G-DKWW9HCKPJ"
            strategy="lazyOnload"
          />

          <Script
            id="gtm-script1"
            dangerouslySetInnerHTML={{
              __html: `
      window.dataLayer = window.dataLayer || [];
      function gtag() {
        dataLayer.push(arguments);
      }
      gtag("js", new Date());
      gtag("config", "G-DKWW9HCKPJ");
      `,
            }}
            strategy="lazyOnload"
          />
          <JsonLd/>

          {/* Google tag (gtag.js)  */}

          <Script
            src="https://www.googletagmanager.com/gtag/js?id=AW-11405194652"
            strategy="lazyOnload"
          />

          <Script
            id="gtm-script2"
            dangerouslySetInnerHTML={{
              __html: `
      window.dataLayer = window.dataLayer || [];
      function gtag() {
        dataLayer.push(arguments);
      }
      gtag("js", new Date());

      gtag("config", "AW-11405194652");
      `,
            }}
            strategy="lazyOnload"
          />
        </head>
        <body>
          <Suspense fallback={<Loading />}>
            <BlogReposContextProvider>
              <Header />
              {children}
              <Footer />
            </BlogReposContextProvider>
          </Suspense>
        </body>
      </html>
    </>
  );
}
