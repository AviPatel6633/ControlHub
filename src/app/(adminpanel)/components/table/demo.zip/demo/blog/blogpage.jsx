"use client";
import React from "react";
import Slider from "@/component/slider/page";
import { useBlogRepos } from "@/context/BlogReposContext";
import parse from 'html-react-parser';
import BlogTabbing from "@/component/blogTabbing/blogTabbing";
const ImageBaseURL = process.env.NEXT_PUBLIC_FRONTEND_URL + "/uploads/blog";

const Blogpage = () => {
  const { blogRepos } = useBlogRepos();
  const LatestReverse = blogRepos.slice(0).reverse().map((element) => { return element; });

  const itemOffset = 0;
  const itemsPerPage = 10;

  const endOffset = itemOffset + itemsPerPage;
  const currentItems = LatestReverse.slice(itemOffset, endOffset);
  return (
    <div>
      {currentItems &&
        currentItems
          .slice(0, 1)
          .map(({ Title, Url, BlogBannerAlt, Content, BlogBanner }) => (
            <Slider
              blog_image={` ${ImageBaseURL}/${BlogBanner}`}
              blog_image_alt={BlogBannerAlt}
              title="Blog"
              subtitle={[<React.Fragment key="0">{parse(`${Title}`)}</React.Fragment>]}
              content={[
                <div key="0" className="blog-slider-banner-title">
                  {parse(`${Content.length <= 350 ? Content : Content.substring(0, 300)}${'  ....'}`)}
                </div>
              ]}
              btn_text='Read More'
              btn_url={`/blog/${Url}/`}
              key="0"
            />
          ))}
      <BlogTabbing />
    </div>
  );
};

export default Blogpage;
