"use client";
import { React, useState, useEffect } from "react";
import { useBlogRepos } from "@/context/BlogReposContext";
import { Container, Row, Col } from "react-bootstrap";
import Link from "next/link";
import Image from "next/image";
import parse from "html-react-parser";
import dateFormat from "dateformat";
import Slider from "@/component/slider/page";
import "../../blogInnerpage.css";
import Linkedinicon from "/public/assets/images/resources/linkedin-icon.png";
import Facebookicon from "/public/assets/images/resources/facebook-icon.png";
import BlogSidebar from "../../../component/blogSidebar/blogSidebar";
import { Modal } from "react-bootstrap";
import Contactform from "../../../component/contactform/page";
import RegisterForm from "../../../component/registerForm/page";
const ImageBaseURL = process.env.NEXT_PUBLIC_FRONTEND_URL + "/uploads/blog";

const BlogInnerPage = ({ slug }) => {
  const { blogRepos } = useBlogRepos();
  const [currentRepo, setCurrentRepo] = useState([]);

  const [page_url, setpage_url] = useState([]);
  useEffect(() => {
    setpage_url(window.location);
  }, []);

  const [modalShow, setModalShow] = useState(false);
  useEffect(() => {
    $("#OpenBlogModel").click(function () {
      setModalShow(true);
    });
  });

  useEffect(() => {
    const findRepo = () => {
      const res = blogRepos.find((repo) => repo.Url === slug);
      setCurrentRepo(res);
    };
    findRepo();
  }, [blogRepos, slug]);

  return (
    <div>
      <Slider
        blog_image={`${ImageBaseURL}/${currentRepo?.BlogBanner}`}
        blog_image_alt={currentRepo?.BlogBannerAlt}
        blog_date={dateFormat(currentRepo?.Date, "dd mmmm yyyy")}
        blog_title={parse(`${currentRepo?.Title}`)}
      />
      <div className="blog-section">
        <Container className="custom-container">
          <Row className="py-4">
            <Col lg={8}>
              <div className="blogpage-content">
                {parse(`${currentRepo?.Content}`)}
              </div>
              <div>
                <Modal
                  show={modalShow}
                  onHide={() => setModalShow(false)}
                  size="xl"
                  aria-labelledby="BlogModal"
                  centered
                  id="BlogModal"
                >
                  <Modal.Header closeButton></Modal.Header>
                  <Modal.Body className="p-5 pt-0">
                    <Contactform model_id="hubspotForm_model"></Contactform>
                  </Modal.Body>
                </Modal>
              </div>
              <div className="social-share-icons">
                <ul>
                  <li>
                    <h5>Share post on</h5>
                  </li>
                  <li>
                    <Link
                      href={`https://www.facebook.com/sharer/sharer.php?u=${page_url}`}
                      target="_blank"
                    >
                      <Image src={Facebookicon} alt="facebook icon" />
                    </Link>
                  </li>
                  <li>
                    <Link
                      href={`https://www.linkedin.com/shareArticle?mini=true&url==${page_url}`}
                      target="_blank"
                    >
                      <Image src={Linkedinicon} alt="linkedin icon" />
                    </Link>
                  </li>
                </ul>
              </div>
            </Col>
            <Col lg={4} className="sidebar-inner d-none d-lg-block">
              <BlogSidebar
                Form={[
                  <div key="1">
                    <Contactform></Contactform>
                  </div>,
                ]}
              />
            </Col>
          </Row>
        </Container>
      </div>
    </div>
  );
};

export default BlogInnerPage;
