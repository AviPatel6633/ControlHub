import axios from "axios";
import BlogInnerPage from './blogInnerPage'

const baseUrl = process.env.NEXT_PUBLIC_BACKEND_URL + "/Blogs/GetBlogData";
const MetadataUrl = process.env.NEXT_PUBLIC_BACKEND_URL + "/SeoMeta/GetData";

// export const dynamic = 'error'
export const dynamicParams = false
// export const dynamic =  'force-static'

export async function generateStaticParams() {
  const response = await axios.get(baseUrl);
  const posts = response.data;
  // const test = posts.map((post) => ({slug: post.Url,}));
  // console.log(test)
  return  posts.map((post) => ({slug: post.Url,}));
};

export async function generateMetadata({ params, searchParams }, parent) {
  // read route params
  // const id = params.id
  const { slug } = params;
  const formdata = { slug: slug };

  // console.log(formdata,'slug')

  // fetch data
  // const product = await fetch(`${MetadataUrl}`).then((res) => res.json())
  const meta = await axios.post(MetadataUrl,formdata);
  const metadata = meta.data;
  // console.log(metadata, 'metadata')
  // optionally access and extend (rather than replace) parent metadata
  // const previousImages = (await parent).openGraph?.images || []
 
  return {
    title: metadata.metaTitle,
    name: metadata.metaTitle,
    description: metadata.metaDesc,
    keywords: metadata.keywords,
    url: metadata.canonical,
    alternates: { canonical: metadata.canonical},
    openGraph: {
      title: metadata.metaTitle,
      description: metadata.metaDesc,
      type: 'website',
      url: metadata.canonical,
      site_name: 'Alphatrucking',
      images: [
        {
          url: `https://alphatrucking.com.au/logo.png`, // Use an absolute URL for the image
          width: 1200, // Add image dimensions for better rendering
          height: 630,
        },
      ],
    },
    robots: {
      index: true,
      follow: true,
    }
  }
}

export default function page({ params }) {
 
  const { slug } = params;

  return (
    <>
          {/* <p>My Post: {slug}</p> */}
          <BlogInnerPage 
            slug={slug}
          />
    </>
  );
}
