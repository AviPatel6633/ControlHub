import React from 'react'
import Blogpage from './blogpage'

export const metadata = {
  title: "Blog | Alpha Trucking",
  name: "Blog | Alpha Trucking",
  description: "Get the inside scoop on freight shipping! Discover industry trends, and find solutions to your freight challenges at the Alpha Trucking blogs.",
  keywords: ["freight broker company", "freight broker"],
  url: "https://alphatrucking.com.au/blog/",
  alternates: { canonical: "https://alphatrucking.com.au/blog/" },
  openGraph: {
    title: "Blog | Alpha Trucking",
    description: "Get the inside scoop on freight shipping! Discover industry trends, and find solutions to your freight challenges at the Alpha Trucking blogs.",
    type: "website",
    url: "https://alphatrucking.com.au/blog/",
    site_name: "Alphatrucking",
    images: [
      {
        url: `https://alphatrucking.com.au/logo.png`,

      },
    ],
  },
  robots: {
    index: true,
    follow: true,
  },
};
const Blog = () => {
  return (
    <div>
        <Blogpage/>
    </div>
  )
}

export default Blog