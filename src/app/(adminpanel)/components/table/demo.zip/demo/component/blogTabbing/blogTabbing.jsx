import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import "./blog-tabbing.css";
import axios from "axios";
import { Container, Col, Row, Nav, Tab, Pagination } from "react-bootstrap";
import date from "/public/assets/images/resources/date-icon.png";
import parse from "html-react-parser";
import dateFormat from "dateformat";
import { useBlogRepos } from "@/context/BlogReposContext";

const baseURL1 = process.env.NEXT_PUBLIC_BACKEND_URL + "/Blogs/GetBlogCategoriesData";
const ImageBaseURL = process.env.NEXT_PUBLIC_FRONTEND_URL + "/uploads/blog";

const BlogTabbing = () => {

  const [categoriesRepos, setCategoriesRepos] = useState([]);
  const [currentCategory, setCurrentCategory] = useState(null);
  const [activeTab, setActiveTab] = useState("first");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setitemsPerPage] = useState(6);
  useEffect(() => {
    if (window.innerWidth <= 786) {
      setitemsPerPage(3);
    } else if ( window.innerWidth > 786) {
      setitemsPerPage(6);
    }
    // const itemsPerPage = 6;
  }, []);

  useEffect(() => {
    axios
      .get(baseURL1)
      .then((res) => {
        const myRepos = res.data;
        if (myRepos != null) {
          const filteredRepos = myRepos?.filter((repo) => repo);
          setCategoriesRepos(filteredRepos);
        } else {
          setCategoriesRepos([]);
        }
      })
      .catch((error) => {
        console.log("Error:", error);
      });
  }, []);

  const { blogRepos } = useBlogRepos();
  const LatestReverse = blogRepos.slice(0).reverse();

  const handleCategoryClick = (categoryId) => {
    const tabKey = categoryId ? categoryId.toString() : "all";
    setActiveTab(tabKey);
    setCurrentCategory(categoryId);
    setCurrentPage(1); 
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = LatestReverse.slice(indexOfFirstItem, indexOfLastItem);

  const totalPages = Math.ceil(LatestReverse.length / itemsPerPage);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  
  const totalCategoryPages = Math.ceil(
    LatestReverse.filter(blog => !currentCategory || blog.CategoryId === currentCategory).length / itemsPerPage
  );
  return (
    <div className="blog-section" id='locate_here'>
      <Container className="custom-container">
        <Tab.Container id="left-tabs-example" defaultActiveKey={activeTab}>
          <Row>
            <Col lg={8}>
              <Tab.Content>
                <Tab.Pane eventKey="first" id='locate_here'>
                  <div className="blog-box-layout">
                    {currentItems.map(
                      ({
                        Title,
                        Url,
                        Id,
                        ThumbnailImage,
                        Description,
                        Date,
                        ThumbnailImageAlt,
                      }) => (
                        <div className="blog-box" key={Id}>
                          <div className="blog-img">
                            <Image
                              alt={ThumbnailImageAlt}
                              src={`${ImageBaseURL}/${ThumbnailImage}`}
                              className="img-fluid"
                              width={500}
                              height={500}
                              style={{ height: "auto", width: "auto" }}
                            ></Image>
                          </div>
                          <div className="blog-details">
                            <h6 className="section-h6-title">
                              <span>
                                <Image
                                  src={date}
                                  alt="date"
                                  className="img-fluid"
                                ></Image>
                              </span>
                              {dateFormat(Date, "dd mmmm yyyy")}
                            </h6>
                            <h5 className="section-h5-title">
                              {parse(
                                `${
                                  Title.length <= 30
                                    ? Title
                                    : Title.substring(0, 30)
                                }`
                              )}
                              ...
                            </h5>
                            <p>
                              {Description.length <= 95
                                ? Description
                                : Description.substring(0, 95)}
                              ...
                            </p>
                            <Link href={`/blog/${Url}/`}>Read More</Link>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                    <Pagination className="page-navigation">
                      {Array.from({ length: totalPages }, (_, index) => (
                        <Pagination.Item
                          key={index + 1}
                          active={index + 1 === currentPage}
                          onClick={() => {
                            paginate(index + 1);
                            const section = document.getElementById('locate_here');
                            if (section) {
                              section.scrollIntoView({ behavior: 'smooth' });
                            }
                          }}
                        >
                          {index + 1}
                        </Pagination.Item>
                      ))}
                    </Pagination>
                </Tab.Pane>
                {categoriesRepos.map((category) => (
                  <Tab.Pane eventKey={category.Id} key={category.Id}>
                    {LatestReverse.filter(
                      (item) => item.CategoryId === category.Id
                    ).length === 0 ? (
                      <h5 className="section-h5-title">No Blogs Available</h5>
                    ) : (
                      ""
                    )}
                    <div className="blog-box-layout">
                      {LatestReverse.filter(
                        (blog) =>
                          !currentCategory ||
                          blog.CategoryId === currentCategory
                      )
                        .slice(indexOfFirstItem, indexOfLastItem)
                        .map((item) => (
                          <div className="blog-box" key={item.Id}>
                            <div className="blog-img">
                              <Image
                                src={`${ImageBaseURL}/${item.ThumbnailImage}`}
                                className="img-fluid"
                                alt={item.ThumbnailImageAlt}
                                width={500}
                                height={500}
                                style={{ height: "auto", width: "auto" }}
                              ></Image>
                            </div>
                            <div className="blog-details">
                              <h6 className="section-h6-title">
                                <span>
                                  <Image
                                    src={date}
                                    alt="date"
                                    className="img-fluid"
                                  ></Image>
                                </span>
                                {dateFormat(item.Date, "dd mmmm yyyy")}
                              </h6>
                              <h5 className="section-h5-title">
                                {parse(
                                  `${
                                    item.Title.length <= 30
                                      ? item.Title
                                      : item.Title.substring(0, 30)
                                  }`
                                )}
                                ...
                              </h5>
                              <p>
                                {item.Description.length <= 95
                                  ? item.Description
                                  : item.Description.substring(0, 95)}
                                ...
                              </p>
                              <Link href={`/blog/${item.Url}/`}>Read More</Link>
                            </div>
                          </div>
                        ))}
                    </div>
                  {totalCategoryPages > 1 && (
                    <Pagination className="page-navigation">
                      {Array.from({ length: totalCategoryPages }, (_, index) => (
                        <Pagination.Item
                          key={index + 1}
                          active={index + 1 === currentPage}
                          onClick={() => {
                            paginate(index + 1);
                            const section = document.getElementById('locate_here');
                            if (section) {
                              section.scrollIntoView({ behavior: 'smooth' });
                            }
                          }}
                        >
                          {index + 1}
                        </Pagination.Item >
                      ))}
                    </Pagination>
                  )}
              </Tab.Pane>
                ))}
              </Tab.Content>
            </Col>
            <Col lg={4} className="sidebar-inner">
              <div className=" sidebar-content">
                <h2 className="section-h2-title">
                  <span>Blogs</span> Category
                </h2>
                <Nav variant="pills" className="flex-column sidebar-c-inner">
                  <Nav.Item className="category-list ">
                    <Nav.Link eventKey="first" className="category-tab">
                      <h5 className="section-h5-title mb-0">All</h5>
                      <span>{LatestReverse.length}</span>
                    </Nav.Link>
                  </Nav.Item>
                  {categoriesRepos.map(({ Id, Title }) => (
                    <Nav.Item className="category-list " key={Id}>
                      <Nav.Link
                        eventKey={Id}
                        className="category-tab"
                        onClick={() => handleCategoryClick(Id)}
                      >
                        <h5 className="section-h5-title mb-0">{Title}</h5>
                        <span>
                          {
                            LatestReverse.filter(
                              (item) => item.CategoryId === Id
                            ).length
                          }
                        </span>
                      </Nav.Link>
                    </Nav.Item>
                  ))}
                </Nav>
              </div>
            </Col>
          </Row>
        </Tab.Container>
      </Container>
    </div>
  );
};

export default BlogTabbing;
