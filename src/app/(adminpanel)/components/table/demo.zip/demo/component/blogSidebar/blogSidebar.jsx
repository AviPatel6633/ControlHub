import React from "react";
import "./blogsidebar.css";
import Contactform from "../contactform/page";
import Link from "next/link";
import Image from "next/image";
import {  Row, Col} from "react-bootstrap";
import { useBlogRepos } from "@/context/BlogReposContext";
import parse from "html-react-parser";

const ImageBaseURL = process.env.NEXT_PUBLIC_FRONTEND_URL + "/uploads/blog";

const BlogSidebar = ( props ) => {
    const { blogRepos } = useBlogRepos();
    const LatestReverse = blogRepos.slice(0).reverse().map(element => {
      return element;
    });  
    const itemOffset = 0;
    const itemsPerPage = 7;

    const endOffset = itemOffset + itemsPerPage;
    const currentItems = LatestReverse.slice(itemOffset, endOffset);

  return (
    <>
      <div className="sidebar-content">
        <div>
          <h2 className="section-h2-title">Recent Blogs</h2>
        </div>
        {currentItems && currentItems.slice(1, 4).map(({ Title, Url, Id, ThumbnailImage, ThumbnailImageAlt }) => (
            <div className="recent-blogs" key={Id}>
                <Row>
                    <Col xl={4} lg={5} className="my-auto">
                        <Image src={`${ImageBaseURL}/${ThumbnailImage}`} className='img-fluid' alt={ThumbnailImageAlt} width={100} height={100} style={{ height: 'auto', width: 'auto', }}></Image>
                    </Col>
                    <Col className="my-auto">
                        <h5 className="section-h5-title">{parse(`${Title.length <= 30 ? Title : Title.substring(0, 35)}`)}...</h5>
                        <Link href={`/blog/${Url}/`}>Read More</Link>
                    </Col>
                </Row>
            </div>
        ))}
        <div className="how-it-works-quote-block animate__animated animate__fadeInUp mx-0">
          <div className="blog-contact-outer-box">
            <h5 className="section-h5-title">Quote or Book A Job Online</h5>
            {/* <Contactform></Contactform> */}
            {props.Form}
          </div>
        </div>
      </div>
    </>
  );
};

export default BlogSidebar;
