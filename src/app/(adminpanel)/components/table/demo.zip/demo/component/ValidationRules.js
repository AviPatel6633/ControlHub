export const ValidationRules =  {
    letters: /^[A-Za-z ]+$/,
    digits: /^[0-9]+$/,
    email: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$/,
    amount:  /^(?!0$)([0-9]+(\.[0-9]+)?)$/,
}